@extends('layout.master');

@section('title')
  Home | University Management System
@endsection

@section('content')

@endsection
