<div class="container-fluid">
  <div class="row">
    <div class="col-md-12">
      <div class="well text-center copyright">
        <p>copyright &copy; <a href="">Sadikur Rahaman</a> 2016</p>
      </div>
    </div>
  </div>
</div>
