;

<?php $__env->startSection('title'); ?>
  Department Entry | University Management System
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <div class="container">
    <div class="row">
      <div class="col-md-8 col-md-offset-2">

        <?php if(Session::has('success')): ?>
          <script>
            var msg = "<?php echo e(Session::get('success')); ?>";
            $(document).ready(function() {
              swal("Done!", msg, "success");
            });
          </script>
        <?php endif; ?>

        <div class="panel panel-default user_form">
          <div class="panel-heading">Add New Department</div>
          <div class="panel-body">
            <form method="POST" action="<?php echo e(Route('postdepartment')); ?>" accept-charset="UTF-8" id="">
              <input name="_token" type="hidden" value="<?php echo e(Session::token()); ?>">

              <div class="form-group <?php echo e($errors->has('deptcode') ?  'has-error' : ''); ?>">
                <label for="code" class="btn-label">Department Code</label>
                <input class="form-control" name="deptcode" type="text" id="code" value="<?php echo e(Request::old('deptcode')); ?>">
                <?php if($errors->has('deptcode')): ?> <label class="help-block"><?php echo e($errors->first('deptcode')); ?></label> <?php endif; ?>
              </div>

              <div class="form-group <?php echo e($errors->has('deptname') ?  'has-error' : ''); ?>">
                <label for="name" class="btn-label">Department Name</label>
                <input class="form-control" name="deptname" type="text" id="name" value="<?php echo e(Request::old('deptname')); ?>">
                <?php if($errors->has('deptname')): ?> <label class="help-block"><?php echo e($errors->first('deptname')); ?></label> <?php endif; ?>
              </div>

              <input class="btn btn-primary" type="submit" value="Save">
            </form>

          </div>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>