<!DOCTYPE html>
<html>
    <head>
      <meta name="name" content="content" charset="utf-8">
        <title>শুভ হালখাতা ২০১৬</title>
        <link rel="stylesheet" href="<?php echo e(URL::to('src/css/bootstrap.min.css')); ?>" media="screen" title="no title" charset="utf-8">
        <link rel="stylesheet" href="<?php echo e(URL::to('src/css/main.css')); ?>" media="screen" title="no title" charset="utf-8">
        <script type="text/javascript" src="<?php echo e(URL::to('src/js/jquery.min.js')); ?>"></script>
        <script type="text/javascript" src="<?php echo e(URL::to('src/js/bootstrap.min.js')); ?>"></script>
    </head>
    <body>
        <div class="container1">
            <img src="<?php echo e(URL::to('src/img/banner.jpg')); ?>" alt="" />
        </div>
    </body>
</html>
